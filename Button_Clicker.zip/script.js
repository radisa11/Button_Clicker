var display = document.getElementById("button1");
function logOut(){
    display.innerText ="Logout";
}
function hide(element){
    element.remove();
}